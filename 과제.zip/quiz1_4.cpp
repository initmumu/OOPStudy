#include <iostream>
using namespace std;

void sort(int* unSorted, int length) {
    /* ���� */
}

void print(int* arr) {
    cout << "[";
    for (int i = 0; i < 10; i++) {
        if (i != 9) {
            cout << arr[i] << ", ";
        }
        else {
            cout << arr[i] << "]" << endl;
        }
    }
}

int main() {
	int unSorted[10] = {45,123,432,64,23,71,67,32,36,98};

	sort(unSorted, 10);

    print(unSorted);

}


