#include <iostream>
using namespace std;

int calcReward(int a, int b, int c) {
	int reward;
	/* ���� */
	return reward;
}

int main() {
	int one, two, three;
	cin >> one >> two >> three;

	cout << "���: " << calcReward(one, two, three) << endl;
}


