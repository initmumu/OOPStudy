#include <iostream>
using namespace std;

void khuTGWinG() {
	/* ���� */
}

int main() {
	khuTGWinG();
}


